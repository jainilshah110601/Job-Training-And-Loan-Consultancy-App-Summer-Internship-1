
<?php

include 'connection.php';

// $data = json_decode($_POST['selectedempid']);
// $selectedempid = json_encode($data);
// echo $selectedempid;

// $sql = "SELECT * FROM tbl_empclient";
$sql = "SELECT * FROM tbl_partnerclient where reference_id = selectedpid";
$result = mysqli_query($conn,$sql);
$user = array();


while($row = mysqli_fetch_assoc($result)){
    $index['client_id'] = $row['client_id'];
    $index['client_name'] = $row['client_name'];
    $index['reference_id'] = $row['reference_id'];
    $index['field'] = $row['field'];

    array_push($user,$index);
    

}
echo json_encode($user);


?>