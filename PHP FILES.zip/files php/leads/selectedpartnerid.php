<?php

include 'connection.php';

  $selectedpartnerid=$_POST['selectedpartnerid'];   
  $insertpartnerleadqry="UPDATE `tbl_partnerclient` SET `selectedpid` = '$selectedpartnerid'";
  mysqli_query($conn,$insertpartnerleadqry);
  
  echo "Inserted Successfully";
?>
