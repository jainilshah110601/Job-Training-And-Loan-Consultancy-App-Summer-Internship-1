<?php

include 'connection.php';

  $selectedempid=$_POST['selectedempid'];   
  $insertempleadqry="UPDATE `tbl_empclient` SET `selectedempid` = '$selectedempid'";
  mysqli_query($conn,$insertempleadqry);
 
     echo "Inserted Successfully";

  
?>
