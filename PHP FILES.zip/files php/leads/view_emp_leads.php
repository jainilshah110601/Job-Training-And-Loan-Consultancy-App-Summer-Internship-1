
<?php

include 'connection.php';

// $sql = "SELECT * FROM tbl_empclient";
$sql = "SELECT * FROM tbl_empclient where reference_id = selectedempid";
$result = mysqli_query($conn,$sql);
$user = array();

//  if(!mysqli_num_rows($result)> 0){
//      echo "No client exist!";
 
//  }else{
 
//      echo "Loading..";
//  }
     
while($row = mysqli_fetch_assoc($result)){
    $index['client_id'] = $row['client_id'];
    $index['client_name'] = $row['client_name'];
    $index['reference_id'] = $row['reference_id'];
    $index['field'] = $row['field'];

    array_push($user,$index);
    

}
echo json_encode($user);


?>