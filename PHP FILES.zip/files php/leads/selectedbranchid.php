<?php

include 'connection.php';

  $selectedbranchid=$_POST['selectedbranchid'];   
  $insertbranchleadqry="UPDATE `tbl_branchclient` SET `selectedbid` = '$selectedbranchid'";
  mysqli_query($conn,$insertbranchleadqry);
  
  echo "Inserted Successfully";
?>
