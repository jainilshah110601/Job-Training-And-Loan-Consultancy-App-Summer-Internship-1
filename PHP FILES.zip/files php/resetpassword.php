<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$oldpass = $_POST['oldpassword'];
$newpass = $_POST['newpassword'];
$email = $_POST['email'];
$sql = "Select * from tbl_user where password = '$oldpass' and email = '$email'";
$query = mysqli_query($conn, $sql);


if(!mysqli_num_rows($query)> 0){
    echo "Old Password didnt match!";

}else{
    $update = "UPDATE tbl_user SET password = '$newpass' where email = '$email'";
    $res = mysqli_query($conn,$update);
    if($res){
        echo "Password Is Successfully Changed!";
    }else{
        echo "Error! :-(";
    }
}


?>