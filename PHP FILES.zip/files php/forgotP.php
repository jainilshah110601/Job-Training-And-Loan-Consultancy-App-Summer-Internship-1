<?php
require 'PHPMailerAutoload.php';
require 'PHPMailer/class.phpmailer.php';
require 'PHPMailer/class.smtp.php';
require 'admin.php';

include 'connection.php';
$conn=mysqli_connect("localhost","root","");
mysqli_select_db($conn,"android_db");

$username = $_GET['fpname'];
$email  = $_GET['fpemail'];

$sql = "SELECT email,password FROM tbl_user WHERE username = '$username' AND email = '$email'"; 



$result = mysqli_query($conn,$sql);
$response = array();

if(mysqli_num_rows($result)>0){

$row = mysqli_fetch_Assoc($result);

 
$to_email = $row['email'];
$subject = 'Forgot Password For Consultancy App "<br>" Information given by you' ;
$message = 'username'.$username. "email" .$email.".";
$headers = 'From: noreply @ company . com'; //optional

// SMTP=smtp.gmail.com
// smtp_port=587
// sendmail_from = YourGmailId@gmail.com
// sendmail_path = "\"C:\xampp\sendmail\sendmail.exe\" -t"

// mail($row['email'],"Your Account Password is ",$row['password'],"Consultancyapp test","consultancyapptest@gmail.com");
mail($to_email,$subject,$message,$headers);
echo "SUCCESS";
}
echo "FAILED";

mysqli_close($conn);

?>