<?php
$adminemail = 'consultancyapptest@gmail.com';
$adminpassword = 'consultancy123';

?>