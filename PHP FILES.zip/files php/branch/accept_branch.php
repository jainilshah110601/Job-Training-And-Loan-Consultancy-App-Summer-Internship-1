<?php

include 'connection.php';
require 'PHPMailerAutoload.php';
require 'PHPMailer/class.phpmailer.php';
require 'PHPMailer/class.smtp.php';
require 'admin.php';

$pass =  $_POST['password'];
$automaticuname =  $_POST['automaticuname'];
$businessname = $_POST['business'];
$fname = $_POST['bname'];
$email  = $_POST['bemail'];

$sql = "SELECT Email FROM tbl_branch WHERE Name = '$fname' AND Email = '$email'"; 

// $sql = "SELECT * FROM tbl_user WHERE email = '$email'";

// $check = mysqli_query($conn,$sql);


$result = mysqli_query($conn,$sql);
$response = array();

if(mysqli_num_rows($result)>0){

$row = mysqli_fetch_Assoc($result);

 
// if($check){

    
$mail = new PHPMailer;

// $mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;  // Enable SMTP authentication

//Enter our sender's email here 

$mail->Username = $adminemail;                 // SMTP username
$mail->Password = $adminpassword;                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom($adminemail, 'Consultancyapp Test');    // Add a recipient 
$mail->addAddress($email);
             // Name is optional
$mail->addReplyTo('consultancyapptest@gmail.com', 'Consultancyapp Test');

//set email format to html
$mail->Subject = ' Consultancy App : Accepted Your Request For Branch';
$mail->Body    = "Dear $businessname , Your request is accepted 
                  \r\nLogin from given below Credentials
                    
                    \r\n Your Username : ".$automaticuname.
                   "\r\n Your password :" .$pass.
                   "\r\n Thank You!";
// $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    // echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'success';
}

}else{

    echo 'Invalid Email';
}


?>