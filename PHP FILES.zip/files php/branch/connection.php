<?php
$conn=mysqli_connect("localhost","id17088137_root","ftW+ipW)vIP5^PG9");
mysqli_select_db($conn,"id17088137_android_db");
?>