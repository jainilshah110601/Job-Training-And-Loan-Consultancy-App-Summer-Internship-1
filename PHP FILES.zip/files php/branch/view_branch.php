
<?php

include 'connection.php';
$sql = "SELECT * FROM tbl_branch";
$result = mysqli_query($conn,$sql);
$user = array();

while($row = mysqli_fetch_assoc($result)){
    $index['Name'] = $row['Name'];
    $index['Branchcode'] = $row['Branchcode'];
    $index['Email'] = $row['Email'];
    $index['Businessname'] = $row['Businessname'];
    $index['Mobile'] = $row['Mobile'];
    $index['Address'] = $row['Address'];
    $index['City'] = $row['City'];
    $index['State'] = $row['State'];
    $index['Pincode'] = $row['Pincode'];
    $index['IFSC'] = $row['IFSC'];
    $index['BankACname'] = $row['BankACname'];
    $index['BankACno'] = $row['BankACno'];
    $index['BankACtype'] = $row['BankACtype'];
    $index['Reference'] = $row['Reference'];
    $index['status'] = $row['status'];

    array_push($user,$index);
    

}
echo json_encode($user);


?>