<?php

  include 'connection.php';
  $bstatus=$_POST['bstatus']; 
  $bcode = $_POST['bcode'];
  $updatebstatus = "UPDATE `tbl_branch` SET `status` = '$bstatus' WHERE `tbl_branch`.`Branchcode` = '$bcode'";
    
//   $updatebstatus="UPDATE `tbl_branch` SET `status` = '$bstatus' WHERE `tbl_branch`.`Branchcode` = `$bcode`;";
  mysqli_query($conn,$updatebstatus);
  
$result = mysqli_query($conn,$updatebstatus);
echo "updated status!";
// if(mysqli_num_rows($result)>0){
  
//   while($data = mysqli_fetch_assoc($result)){
//              echo "updated status!";
//         }
// }
// else{
//     echo "failed";
// }
?>
