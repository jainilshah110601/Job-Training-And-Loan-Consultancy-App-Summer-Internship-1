<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$uname=$_POST['t3'];
$pwd=$_POST['t4'];
$email=$_POST['t2'];

$qry="select * from tbl_user where username='$uname' and password='$pwd' and email = '$email'";

$raw=mysqli_query($conn,$qry);

$count=mysqli_num_rows($raw);

if($count>0)
 echo "found";
else
 echo "not found";
?>