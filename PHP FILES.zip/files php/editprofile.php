<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$uname=$_POST['adminuser'];
$email=$_POST['adminemail'];

$updateduname=$_POST['updateduser'];
$updatedemail=$_POST['updatedemail'];

 $sql = "Select * from tbl_user where username = '$uname' and email = '$email'";
 $query = mysqli_query($conn, $sql);
 
 
 if(!mysqli_num_rows($query)> 0){
     echo "No such user exist!";
 
 }else{
    
    //  while ( $row = mysqli_fetch_assoc($query)) {
    //     $id = $row['id'];
    //    }
     //$id = '$row["id"]';
     $update = "UPDATE tbl_user SET username = '$updateduname',email='$updatedemail' where id in (select id from tbl_user where username = '$uname' and email = '$email')";
     //$update = "UPDATE tbl_user SET username = 'Neha' and email = 'NEha123@gmail.com' where id in (select id from tbl_user where username = '$uname' and email = '$email')";
     //$update = "UPDATE tbl_user SET username = '$updateduname' and email = '$updatedemail' where id ='$id'";
     $res = mysqli_query($conn,$update);
     if($res){
         echo "Profile Is Successfully Updated!";
     }else{
         echo "Error! :-(";
     }
 }
 
 
 ?>
