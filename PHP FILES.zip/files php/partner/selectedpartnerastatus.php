<?php

  include 'connection.php';
  $pstatus=$_POST['pstatus']; 
  $pcode = $_POST['pcode'];
  $updatepstatus = "UPDATE `tbl_partner` SET `status` = '$pstatus' WHERE `tbl_partner`.`partnerCode` = '$pcode'";
//   $updatebstatus="UPDATE `tbl_branch` SET `status` = '$bstatus' WHERE `tbl_branch`.`Branchcode` = `$bcode`;";
  mysqli_query($conn,$updatepstatus);
  
$result = mysqli_query($conn,$updatepstatus);
echo "updated status!";
// if(mysqli_num_rows($result)>0){
  
//   while($data = mysqli_fetch_assoc($result)){
//              echo "updated status!";
//         }
// }
// else{
//     echo "failed";
// }
?>
