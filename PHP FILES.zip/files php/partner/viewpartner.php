
<?php
include 'connection.php';
$sql = "SELECT * FROM tbl_partner";
$result = mysqli_query($conn,$sql);
$user = array();

while($row = mysqli_fetch_assoc($result)){
    $index['userName'] = $row['userName'];
    $index['partnerCode'] = $row['partnerCode'];
    $index['email'] = $row['email'];
    $index['businessname'] = $row['businessname'];
    $index['mobile'] = $row['mobile'];
    $index['Address'] = $row['Address'];
    $index['City']=$row['City'];
    $index['State']=$row['State'];
    $index['PinCode']=$row['PinCode'];
    $index['IFSC']=$row['IFSC'];
    $index['bankname']=$row['bankname'];
    $index['ACno']=$row['ACno'];
    $index['Reference']=$row['Reference'];
    $index['status']=$row['status'];

    array_push($user,$index);
    

}
echo json_encode($user);


?>