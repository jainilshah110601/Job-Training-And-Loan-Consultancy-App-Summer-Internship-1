<?php

include 'connection.php';
$email =$_POST['email'];

$selectquery = "SELECT * FROM tbl_emp WHERE email = '$email'";
$check = mysqli_query($conn,$selectquery);
$result = array();
if(mysqli_num_rows($check) == 1){
    $deletequery = "DELETE FROM tbl_emp WHERE email ='$email'";
    if(mysqli_query($conn,$deletequery)){ 
        $result['state'] = "delete";
        echo json_encode($result);
    }else{
        echo "User Already Deleted!";
    }
}else{
    echo "Invalid User or Deleted User";
}



?>