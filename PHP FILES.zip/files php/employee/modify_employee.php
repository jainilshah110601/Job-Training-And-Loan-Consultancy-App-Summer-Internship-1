<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$oldfname=$_POST['oldemfullname'];
$olduname=$_POST['oldemusername'];
$oldemail=$_POST['oldememailid'];
// $oldpassword=$_POST['oldempassword'];
$oldjoindate=$_POST['oldemjoindate'];
$oldbranch=$_POST['oldembranch'];
$olddiv=$_POST['oldemdiv'];
$oldmobile=$_POST['oldemmobno'];
$oldCTC=$_POST['oldemCTC'];



$updatedfname=$_POST['emfullname'];
$updateduname=$_POST['emusername'];
$updatedemail=$_POST['ememailid'];
// $updatedpassword=$_POST['empassword'];
$updatedjoindate=$_POST['emjoindate'];


$updatedbranch=$_POST['embranch'];
$updateddiv=$_POST['emdiv'];
$updatedmobile=$_POST['emmobno'];
$updatedCTC=$_POST['emCTC'];

 $sql = "Select * from tbl_emp where email = '$oldemail'";
 $query = mysqli_query($conn, $sql);
 
 
 if(!mysqli_num_rows($query)> 0){
     echo "No such user exist!";
 
 }else{
   
    $update = "UPDATE tbl_emp SET username = '$updateduname',email = '$updatedemail',fullname = '$updatedfname',branch = '$updatedbranch',division = '$updateddiv',CTC='$updatedCTC',mobile='$updatedmobile',joining_date = '$updatedjoindate' where id in (select id from tbl_emp where username = '$olduname' and email = '$oldemail')";
    $res = mysqli_query($conn,$update);
     if($res){
         echo "Employee Details Are Successfully Updated!";
     }else{
         echo "Error! :-(";
     }
 }
 
 
 ?>
