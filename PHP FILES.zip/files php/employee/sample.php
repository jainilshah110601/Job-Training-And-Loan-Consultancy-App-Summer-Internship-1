<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$email =$_POST['email'];

$check = "SELECT * FROM tbl_emp WHERE email = '$email'";
$result = mysqli_query($conn,$check);

if(mysqli_num_rows($result)==1){
    $sql = "DELETE FROM tbl_emp WHERE email = '$email'";
    if(mysqli_query($conn,$sql)){
        echo "Employee Deleted Successfully";
    }else{
        echo "Employee is already deleted!";
    }

}else{
    echo "Employee Unavailable!";
}


?>