<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';

  $fname=$_POST['t1'];
  $uname=$_POST['t2'];
  $email=$_POST['t3'];
  $pwd=$_POST['t4'];
  $joindate=$_POST['t5'];
  $hash = password_hash($pwd,PASSWORD_DEFAULT);
  $br=$_POST['t6'];
  $div=$_POST['t7'];
  $mn=$_POST['t8'];
  $ctc=$_POST['t9'];
  
  
  
  
  $qry="INSERT INTO `tbl_emp` (`id`, `fullname`, `username`,`email`, `password`,`joining_date`,`branch`,`division`,`mobile`,`CTC`) VALUES 
  (NULL, '$fname', '$uname', '$email','$hash','$joindate','$br','$div','$mn','$ctc')";
  mysqli_query($conn,$qry);
  
 echo 'Inserted data successfully';
  
?>