
<?php
// $conn=mysqli_connect("localhost","root","");
// mysqli_select_db($conn,"android_db");
include 'connection.php';
$sql = "SELECT * FROM tbl_emp";
$result = mysqli_query($conn,$sql);
$user = array();

while($row = mysqli_fetch_assoc($result)){
    $index['id'] = $row['id'];
    $index['fullname'] = $row['fullname'];
    $index['username'] = $row['username'];
    $index['password'] = $row['password'];
    $index['joining_date'] = $row['joining_date'];
    $index['email'] = $row['email'];
    $index['branch']=$row['branch'];
    $index['division']=$row['division'];
    $index['CTC']=$row['CTC'];
    $index['mobile']=$row['mobile'];
    array_push($user,$index);
    

}
echo json_encode($user);


?>