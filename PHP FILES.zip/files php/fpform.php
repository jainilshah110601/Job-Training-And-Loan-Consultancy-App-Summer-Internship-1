<?php

include 'connection.php';
$email = $_GET['email'];
$username = $_GET['username'];

$sql = "SELECT * from tbl_user where email = '$email' and username = '$username'";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result) == 1){

    if(isset($_POST['submit'])){
    
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];
    
        if(empty($password) && empty($cpassword))
        {
            echo "All Fields Are Required!";
        }
        else
        {
            if($password == $cpassword && $password!="" && $cpassword!=""){
                $update = "UPDATE tbl_user SET password ='$password' WHERE email='$email' and username = '$username'";
                if(mysqli_query($conn,$update)){
                    echo "<div class='centerabc bottom'><h2> <center>Password is changed Successfully! </center></h2></div>";
                }else{
                    echo "<div class='centerabc bottom'><h2><center>Error ! password didn't change & reclick the email link! </center></h2></div>";
                }    
            }
            else{
                echo "<div class='centerabc bottom'><h2><center>password doesn't match!</center></h2></div>";
            }
        }
    }
    else{
        echo "<div class='centerabc bottom'><h2><center>click on Submit button and change ur password</center></h2></div>";
    }
    
}
    
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Password Reset For Consultancy App </title>
</head>

<body>
    <style type="text/css">
    .jumbotron {
        padding: 4rem 2rem;
        margin-bottom: 2rem;
        background-color: #BFBFBF;
        /* background-color: var(--bs-grey); */
        border-radius: .3rem;
    }
    </style>


    <div class="container my-3">
        <div class="jumbotron">
            <h1 class="display-4"><?php echo "Welcome " .$username ?></h1>
            <hr class="my-4">
            <!-- <p>Password Reset For Consultancy App
        <h1><?php echo "Welcome " .$username ?></h1> -->
            <h2>Password Reset For Consultancy App</h2>
            
            <form action="" method="post">
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                        <input type="Email" readonly class="form-control-plaintext" id="inputEmail" required
                            value=<?php echo $email ?>>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">New Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" id="inputPassword" required name="password">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Confirm Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" id="inputPassword" required name="cpassword">
                    </div>
                </div>


                <p class="lead">
                    <input type="submit" name="submit" value="submit">
                    <!-- <a class="btn btn-primary btn-lg" role="button" name="submit">submit</a> -->
                </p>
            </form>
            
        </div>
    </div>
    <!-- 
<input type="submit" value="submit" name="submit"> -->

</body>

</html>